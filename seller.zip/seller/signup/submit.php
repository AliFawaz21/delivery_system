<?php
// Database connection
$conn = new mysqli('localhost', 'root', '', 'delivery_order_tracking_system');

if ($conn->connect_error) {
    die('Connection failed: ' . $conn->connect_error);
}

// Handle form submission
if(isset($_POST['submR'])){
    if(empty($_POST['CBox'])){
        echo "<script>alert('Please select your type');</script>";
    } else {
        $sn = $_POST['sn'];
        $emailin = $_POST['emailin'];
        $pass = $_POST['pass'];
        $teli = $_POST['teli'];
        $CBox = $_POST['CBox'];
        $long = $_POST['longitude'];
        $lat = $_POST['latitude'];
        $addr = $_POST['addr'];
        $hashed_password = password_hash($pass, PASSWORD_DEFAULT);

        // Check for duplicate email
        $check_sql = "SELECT Email FROM seller WHERE Email = ?";
        $check_stmt = $conn->prepare($check_sql);
        $check_stmt->bind_param("s", $emailin);
        $check_stmt->execute();
        $check_stmt->store_result();

        if ($check_stmt->num_rows > 0) {
            echo "<script>alert('Email already registered.'); window.history.back();</script>";
            $check_stmt->close();
            $conn->close();
            exit();
        }
        $check_stmt->close();

      // Fetch the ID for the selected type
$type_sql = "SELECT ID FROM shoptypes WHERE type = ?";
$type_stmt = $conn->prepare($type_sql);
$type_stmt->bind_param("s", $CBox);
$type_stmt->execute();
$type_stmt->bind_result($type_id);
$type_stmt->fetch();
$type_stmt->close();

if (!$type_id) {
    echo "<script>alert('Invalid shop type selected.'); window.history.back();</script>";
    exit();
}

// Insert data with the type ID
$sql = "INSERT INTO seller (Name, Email, Password, phone, Type, Longitude, Latitude, Address) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("ssssddss", $sn, $emailin, $hashed_password, $teli, $type_id, $long, $lat, $addr);

        if ($stmt->execute()) {
            $last_id = $stmt->insert_id;  // Get the newly inserted seller ID
        
            // Handle the icon upload
            if (isset($_FILES['icon']) && $_FILES['icon']['error'] == UPLOAD_ERR_OK) {
                $icon_tmp = $_FILES['icon']['tmp_name'];
                $icon_ext = pathinfo($_FILES['icon']['name'], PATHINFO_EXTENSION);
                $icon_filename = $last_id . '.' . $icon_ext;
                $icon_path = __DIR__ . "/../seller/Icons/" . $icon_filename;
        
                if (!move_uploaded_file($icon_tmp, $icon_path)) {
                    echo "<script>alert('Failed to upload icon image.');</script>";
                }
            }
        
            header("Location: /seller/login/LogIn.php");
            exit();
        } else {
            echo "Error: " . $stmt->error;
        }

        $stmt->close();
        $conn->close();
    }
}

// Fetch shop types from database
$shop_types = [];
$type_query = "SELECT type FROM shoptypes";
$type_result = $conn->query($type_query);
if ($type_result) {
    while ($row = $type_result->fetch_assoc()) {
        $shop_types[] = $row['type'];
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=no">
    <title>Seller Registration</title>
    <link rel="stylesheet" href="signup.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
</head>
<body>

<div class="wrapper">
    <h1>Registration</h1>
    <form action="" method="POST" enctype="multipart/form-data" onsubmit="return validateInput()">
        <div class="input-box">
            <label>Store Name:</label>
            <input type="text" id="str" name="sn" placeholder="Enter your store name" required>
        </div>

        <div class="input-box">
            <label>Email:</label>
            <input type="email" id="email" name="emailin" placeholder="Enter your email" required>
        </div>

        <div class="input-box">
            <label>Password:</label>
            <input type="password" id="password" name="pass" placeholder="Enter your password" required>
        </div>

        <div class="input-box">
            <label>Confirm Password:</label>
            <input type="password" id="confPass" placeholder="Confirm your password" required>
        </div>

        <div class="input-box">
            <label>Phone Number:</label>
            <input type="tel" id="phone" name="teli" placeholder="Enter your phone number" required>
        </div>

        <label for="CB">What are you selling:</label>
        <select class="combo" id="CB" name="CBox" required>
            <option value="">Select...</option>
            <?php foreach ($shop_types as $type): ?>
                <option value="<?php echo htmlspecialchars($type); ?>"><?php echo htmlspecialchars($type); ?></option>
            <?php endforeach; ?>
        </select>
        
        <div class="input-image">
            <label style="margin-right: 50px;">Icon:</label>
            <div class="icon">
                <input type="file" name="icon" id="icon" accept="image/*" required>
            </div>
        </div>
        
        <div class="input-box">
            <label>Longitude:</label>
            <input type="text" name="longitude" id="longitude" readonly>
            <label>Latitude:</label>
            <input type="text" name="latitude" id="latitude" readonly>
            <label>Location:</label>
            <input type="text" name="addr" id="location" readonly>
        </div>

        <div id="map"></div>
        
        <button type="submit" name="submR" class="btn">Submit</button>
    </form>

    <p id="warning"></p>
</div>

<script>
    function validateInput() {
        let pass = document.getElementById("password").value.trim();
        let conPass = document.getElementById("confPass").value.trim();
        let warningMessage = document.getElementById("warning");

        if (pass !== conPass) {
            warningMessage.textContent = "Passwords do not match!";
            warningMessage.style.color = "red";
            return false;
        }

        return true;
    }

    // Map script
    const defaultCoords = [33.8547, 35.8623]; 
    const map = L.map('map').setView(defaultCoords, 8);
    
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        attribution: '&copy; OpenStreetMap contributors'
    }).addTo(map);

    let marker = L.marker(defaultCoords, { draggable: true }).addTo(map);

    function updateLocation(lat, lng) {
        document.getElementById('latitude').value = lat;
        document.getElementById('longitude').value = lng;

        fetch(`https://nominatim.openstreetmap.org/reverse?format=json&lat=${lat}&lon=${lng}`)
            .then(response => response.json())
            .then(data => {
                document.getElementById('location').value = data.display_name || 'Location not found';
            })
            .catch(() => {
                document.getElementById('location').value = 'Location not found';
            });
    }

    if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(position => {
            const { latitude, longitude } = position.coords;
            map.setView([latitude, longitude], 12);
            marker.setLatLng([latitude, longitude]);
            updateLocation(latitude, longitude);
        });
    }

    map.on('click', function (event) {
        const { lat, lng } = event.latlng;
        marker.setLatLng([lat, lng]);
        updateLocation(lat, lng);
    });

    marker.on('dragend', function(event) {
        const position = marker.getLatLng();
        updateLocation(position.lat, position.lng);
    });
</script>

</body>
</html>
<?php
$conn->close();
?>