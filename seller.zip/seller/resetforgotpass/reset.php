<?php
session_start();
require 'C:\xampp\htdocs\seller\config.php'; 


if (isset($_POST['resetP'])) {
  if ($_SESSION['id'] == "") {
    header("Location: /seller/resetforgotpass/PassForg.html");
    echo $_SESSION['id'];
    exit();
}

  else{
    $new_password = $_POST['new_password'];
    $seller_id = $_SESSION['id'];

    $hashed_password = password_hash($new_password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare("UPDATE seller SET password = ? WHERE id = ?");
    if ($stmt->execute([$hashed_password, $seller_id])) {
        echo "<script>alert('Password reset successful!');</script>";
        session_destroy(); 
        header("Location: http://localhost/seller/login/logIn.php"); 
        exit();
    } else {
        echo "<script>alert('Error updating password.');</script>";
    }
}}
?>

