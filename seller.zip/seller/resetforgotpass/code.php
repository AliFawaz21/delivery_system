<?php
session_start();
require 'C:\xampp\htdocs\seller\config.php';
use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;
use PHPMailer\PHPMailer\SMTP;

require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';
require 'PHPMailer/src/Exception.php';

if (isset($_POST['sendC'])) {
    $email = trim($_POST['email']);

    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        echo "Invalid email format.";
        exit();
    }

    
    $stmt = $pdo->prepare("SELECT id FROM seller WHERE email = ?");
    $stmt->execute([$email]);
    $seller = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($seller) {
        $_SESSION['email'] = $email;
        $id = $seller['id'];
        $_SESSION['id'] = $id;

        
        $verification_code = rand(1000, 9999);
        $_SESSION['verification_code'] = $verification_code;

         $mail = new PHPMailer(true);
        try {
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'afkcamper2003@gmail.com';
            $mail->Password = 'lasq zfqh vfxz dtva'; 
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            $mail->setFrom('afkcamper2003@gmail.com', 'Tracking Delivery Web');
            $mail->addAddress($email);
            $mail->Subject = "Password Reset Code";
            $mail->Body = "Your verification code is: " . $verification_code;

            if ($mail->send()) {
                header("Location: http://localhost/seller/resetforgotpass/codepage.html");
                exit();
            } else {
                echo "Email sending failed.";
            }
        } catch (Exception $e) {
            echo "Email sending failed: " . $mail->ErrorInfo;
        }
    } else {
        header("Location: http://localhost/seller/resetforgotpass/codepage.html");
        exit();
    }
}
?>
