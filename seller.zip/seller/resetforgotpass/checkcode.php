<?php
session_start();
require 'C:\xampp\htdocs\seller\config.php';

if (isset($_POST['Scode'])) {
    $verCode = $_SESSION['verification_code'];
    $user_code = $_POST['Code'];
    echo $_SESSION['verification_code'];
    echo " ";
    echo $_POST['Code'];
    if ($user_code == $verCode) {
        header("Location: /seller/resetforgotpass/resetpassword.html");
        echo "done!";
         exit();
        // Stop script execution after redirect
    } else {
        echo "Invalid code. Please try again.";
    }
    
   }
?>
