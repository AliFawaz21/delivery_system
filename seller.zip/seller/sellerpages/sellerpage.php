﻿<?php
session_start();
require 'C:\xampp\htdocs\seller\config.php'; 

if (!isset($_SESSION['id'])) {
    header("Location: http://localhost/seller/login/logIn.php"); 
}

$seller_id = $_SESSION['id'];
$selname = $_SESSION['selname'];
$seltype = $_SESSION['seltype'];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $action = $_POST['action'] ?? '';
    
    if ($action === "get_product_details") {
        $product_id = $_POST['product_id'] ?? 0;
        
        $stmt = $pdo->prepare("SELECT * FROM product WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();

        if ($product) {
            $stmt = $pdo->prepare("SELECT image_path FROM image WHERE product_id = ?");
            $stmt->execute([$product_id]);
            $images = $stmt->fetchAll(PDO::FETCH_COLUMN);

            $output = "<div id='productDetailsModal' class='detailmodal' onclick='closeModal(event)'>
                        <div class='modal-content'>
                            <span class='close' onclick='closeModal(event)'>&times;</span>
                            <h3>" . htmlspecialchars($product['Name']) . "</h3>
                            <p>Description: " . nl2br(htmlspecialchars($product['description'])) . "</p>
                            <p>Price: $" . number_format($product['Price'], 2) . "</p>
                            <p>Amount Left: " . htmlspecialchars($product['amount']) . "</p>
                            <div class = 'imagesR'><h4>Images:</h4>";

            foreach ($images as $image) {
                $output .= "<img src='" . htmlspecialchars($image) . "' alt='Product Image' style='width: 100px; height: auto;'/>";
            }

            $output .= "</div></div></div> 
                        ";
            echo $output;
        } else {
            echo "error|Product not found";
        }

        exit;
    }

    if ($action === "edit_product") {
    $product_id = $_POST['product_id'] ?? 0;
    $name = $_POST['name'] ?? '';
    $description = $_POST['description'] ?? '';
    $price = $_POST['Price'] ?? 0;
    $amount = $_POST['amount'] ?? 0;

    if (empty($product_id) || empty($name) || empty($price) || empty($amount)) {
        echo "Missing required fields";
        exit;
    }

    $stmt = $pdo->prepare("UPDATE product SET `Name` = ?, `description` = ?, Price = ?, amount = ? WHERE id = ?");
    $stmt->execute([$name, $description, $price, $amount, $product_id]);

    // Fetch category_id for image saving path
    $stmt = $pdo->prepare("SELECT category_id FROM product WHERE id = ?");
    $stmt->execute([$product_id]);
    $row = $stmt->fetch();
    $category_id = $row['category_id'] ?? null;

    if (!empty($_FILES['images']['name'][0]) && $category_id !== null) {
        saveProductImages($pdo, $category_id, $product_id);
    }

    echo "success";
    exit;
}

   if ($action === "get_orders") {
    $query = "
        SELECT o.id, o.Total_Price, o.Date_Time, o.Status,
               c.Name AS customer_name, 
               GROUP_CONCAT(p.Name SEPARATOR ', ') AS product_names,
               GROUP_CONCAT(oi.Quantity SEPARATOR ', ') AS quantities
        FROM `order` o
        JOIN customer c ON o.customer_id = c.id
        JOIN order_items oi ON o.id = oi.Order_id
        JOIN product p ON oi.Product_id = p.id
        JOIN category cat ON p.category_id = cat.id
        WHERE cat.Seller_id = ?
        GROUP BY o.id
        ORDER BY o.Date_Time DESC
    ";

    $stmt = $pdo->prepare($query);
    $stmt->execute([$seller_id]);
    $orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $output = "<div id='ordersModal' class='modal'><div class='modal-content'>";
    $output .= "<span class='close' onclick='$(\"#ordersModal\").hide()'>&times;</span>";
    $output .= "<h3>List Of Orders</h3>";

    if (count($orders) === 0) {
        $output .= "<p>No orders found.</p>";
    } else {
        foreach ($orders as $order) {
            $statusText = "";
            switch ($order['Status']) {
                case 0: $statusText = "Pending"; break;
                case 1: $statusText = "Processing"; break;
                case 2: $statusText = "Shipped"; break;
                case 3: $statusText = "Delivered"; break;
                case 4: $statusText = "Cancelled"; break;
                default: $statusText = "Unknown"; break;
            }
            
            $output .= "<div class='order-item'>";
            $output .= "<p><strong>Order ID:</strong> #" . htmlspecialchars($order['id']) . "</p>";
            $output .= "<p><strong>Customer:</strong> " . htmlspecialchars($order['customer_name']) . "</p>";
            $output .= "<p><strong>Products:</strong> " . htmlspecialchars($order['product_names']) . "</p>";
            $output .= "<p><strong>Quantities:</strong> " . htmlspecialchars($order['quantities']) . "</p>";
            $output .= "<p><strong>Total:</strong> $" . number_format($order['Total_Price'], 2) . "</p>";
            $output .= "<p><strong>Date:</strong> " . htmlspecialchars($order['Date_Time']) . "</p>";
            $output .= "<p><strong>Status:</strong> " . $statusText . "</p>";
            $output .= "</div><hr>";
        }
    }

    $output .= "</div></div>";
    echo $output;
    exit;
}

    if ($action === "get_product") {
    $product_id = $_POST['product_id'] ?? 0;
    $stmt = $pdo->prepare("SELECT * FROM product WHERE id = ?");
    $stmt->execute([$product_id]);
    $product = $stmt->fetch();

    if ($product) {
        echo $product['id'] . '|' . $product['Name'] . '|' . $product['description'] . '|' . $product['Price'] . '|' . $product['amount'];
    } else {
        echo "error|Product not found";
    }

    exit;
}

    if($action === "commentsRev"){
        $product_id = $_POST['product_id'] ?? 0;
        $review_query = "SELECT c.Name AS customer_name, r.Date, r.Comments, r.Rating
                 FROM Review r
                 JOIN Customer c ON r.customer_id = c.id
                 WHERE r.product_id = ? 
                 ORDER BY r.Date DESC";

$stmt = $pdo->prepare($review_query);
$stmt->execute([$product_id]);
$result = $stmt->fetchAll();

$output = "";
if (count($result) > 0) {
    $output .= "<div id='Cmodal' class='modal'>";
    $output .= "<div class='modal-content'>";
    $output .= "<span class='close' onclick='$(\"#Cmodal\").hide()'>&times;</span>";
    $output .= "<h3>Customer Reviews</h3>";

    foreach ($result as $row) {
        $output .= "<div class='review'>";
        $output .= "<strong>" . htmlspecialchars($row['customer_name']) . "</strong> ";
        $output .= "(<small>" . htmlspecialchars($row['Date']) . "</small>)<br>";
        $output .= "<p>" . nl2br(htmlspecialchars($row['Comments'])) . "</p>";
        $output .= "<p>Rating: " . str_repeat("⭐", intval($row['Rating'])) . "</p>";
        $output .= "</div><hr>";
    }

    $output .= "</div></div>";
} else {
    $output = "<div id='Cmodal' class='modal'><div class='modal-content'><span class='close' onclick='$(\"#Cmodal\").hide()'>&times;</span><p>No reviews yet for this product.</p></div></div>";
}


echo $output;
exit;

    }

    


    if ($action === "add_Category") {
        $Cname = $_POST['categoryName'] ?? ''; 
        if (empty($Cname)) {
            echo json_encode(["error" => "Category name required"]);
            exit;
        }

        addCategory($pdo, $seller_id);
    }

    if ($action === "add_product") {
        $category_id = $_POST['category_id'] ?? 0;
        $name = $_POST['name'] ?? '';
        $description = $_POST['description'] ?? '';
        $price = $_POST['price'] ?? 0;
        $amount = $_POST['amount'] ?? 0;
        if (empty($category_id) || empty($name) || empty($price) || empty($amount)) {
            echo json_encode(["error" => "Missing required fields"]);
            exit;
        }

        addProduct($pdo, $category_id, $name, $description, $price, $amount);
    }
}



function fetchCategoriesAndProducts($pdo, $seller_id) {
    $response = [];

    $stmt = $pdo->prepare("SELECT * FROM category WHERE seller_id = ?");
    $stmt->execute([$seller_id]);
    $categories = $stmt->fetchAll();

    foreach ($categories as &$category) {
        $category_id = $category['id'];

        $stmt = $pdo->prepare("SELECT * FROM product WHERE category_id = ?");
        $stmt->execute([$category_id]);
        $products = $stmt->fetchAll();

        foreach ($products as &$product) {
            $product_id = $product['id'];

            $stmt = $pdo->prepare("SELECT image_path FROM image WHERE product_id = ? ORDER BY id ASC");
            $stmt->execute([$product_id]);
            $images = $stmt->fetchAll();

            $product['images'] = array_column($images, 'image_path');
            $product['main_image'] = count($images) > 0 ? $images[0]['image_path'] : "no_image.jpg";
        }
        foreach ($products as &$product){
            $product_id = $product['id'];

            $stmt = $pdo->prepare("SELECT AVG(Rating) AS average_rating FROM review WHERE product_id = ?");
    $stmt->execute([$product_id]);
    $rate = $stmt->fetch();
    $product['rating'] = $rate['average_rating'] ?? 'N/A';


        }
        $category['products'] = $products;
    }

    return $categories;
}

function addCategory($pdo, $seller_id) {
    header('Content-Type: application/json'); 

    if (!isset($_POST['categoryName'])) {
        echo json_encode(["error" => "Category Name required"]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO category (seller_id, Name) VALUES (?, ?)");
        $stmt->execute([$seller_id, $_POST['categoryName']]);
        header("Refresh:1");
        echo json_encode(["success" => "Category added"]);
    } catch (Exception $e) {
        echo json_encode(["error" => "Database error: " . $e->getMessage()]);
    }
    
            


    exit;
}

function addProduct($pdo, $category_id, $name, $description, $price, $amount) {
    header('Content-Type: application/json');

    if (empty($category_id) || empty($name) || empty($price) || empty($amount)) {
        echo json_encode(["error" => "Missing required fields"]);
        exit;
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO product (category_id, Name, description, Price, amount) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$category_id, $name, $description, $price, $amount]);

        $product_id = $pdo->lastInsertId();
        $imagesSaved = saveProductImages($pdo, $category_id, $product_id); 

        if ($imagesSaved) {
            echo json_encode(["success" => "Product added with images"]);
        } else {
            echo json_encode(["success" => "Product added"]);
        }
    } catch (Exception $e) {
        echo json_encode(["error" => "Database error: " . $e->getMessage()]);
    }
    exit;
}



function saveProductImages($pdo, $category_id, $product_id) {
    $uploadDir = "pictures/{$_SESSION['id']}/{$category_id}/{$product_id}/";
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0777, true);
    }

    $imagesUploaded = false;
    $currentCount = count(glob($uploadDir . "*"));

    foreach ($_FILES['images']['tmp_name'] as $index => $tmpName) {
        $fileName = ($currentCount + $index + 1) . '.' . pathinfo($_FILES['images']['name'][$index], PATHINFO_EXTENSION);
        $filePath = $uploadDir . $fileName;

        if (move_uploaded_file($tmpName, $filePath)) {
            $stmt = $pdo->prepare("INSERT INTO image (product_id, image_path) VALUES (?, ?)");
            $stmt->execute([$product_id, $filePath]);
            $imagesUploaded = true;
        }
    }

    return $imagesUploaded;
}


?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Page</title>
    <link rel="stylesheet" href="selP.css">
    <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
 
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1><?php echo isset($selname) ? htmlspecialchars($selname) : "No Heading Set"; ?></h1>
            <img src="/seller/Icons/<?php echo htmlspecialchars($seller_id); ?>.jpg" alt="Icon" class="icon">
        </div>
        <div class="search-container">
            <input type="text" id="searchInput" placeholder="Search categories and products...">
            <button onclick="clearSearch()" class="clear-search">Clear</button>
        </div>
        
        <div class="seller-info">
            <button class="add-button" onclick="openCategoryModal()">Add Category</button>
            <p> <strong><?php echo htmlspecialchars($seltype); ?> Shop</strong></p>
            <button class="view-orders-button" onclick="viewOrders()">View Orders</button>
        </div>
        <div id="sections">
            <?php 
            $categories = fetchCategoriesAndProducts($pdo, $seller_id);
            if (empty($categories)) {
                echo "<p>No categories found.</p>";
            } else {
                foreach ($categories as &$category) {
                    echo "<div class='section'>
                            <h3>{$category['Name']}</h3>
                            <div class='product-list'>";
                    foreach ($category['products'] as &$product) {
                        $mainImage = $product['main_image'] ?: "no_image.jpg";
                        echo "<div class='product-item'>
                                <img src='{$mainImage}' alt='{$product['Name']}' style='width: 100px; height: auto;'>
                                <p><strong>{$product['Name']}</strong></p>
                                <p>{$product['description']}</p>
                                <p><strong>Price:</strong> $ {$product['Price']}</p>
                                <p><strong>Amount Left:</strong> {$product['amount']}</p>
                                <p><strong>Rating:</strong> " . 
                                    (is_numeric($product['rating']) ? number_format($product['rating'], 1) : 'No reviews') . 
                                    "</p>
                                <div class='symbols'>
                                    <span class='material-icons' style='cursor: pointer;' onclick='commentmod({$product['id']})'>comment</span>
                                    <span class='material-icons' style='cursor: pointer;' onclick='openProductDetails({$product['id']})'>info</span>
                                    <span class='material-icons' style='cursor: pointer;' onclick='openEditproduct({$product['id']})'>edit</span>
                                </div>
                              </div>";
                    }
                    echo "<button class='add-button-p' onclick='openProductModal({$category['id']})'> + </button></div></div>";
                }
            }
            ?>
        </div>
        <div class="orders">
            <a href="http://localhost/seller/login/logIn.php" class="logout-button">Logout</a>
        </div>  
    </div>

    <!-- Category Modal -->
    <div id="categoryModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeCategoryModal()">&times;</span>
            <h3>Add Category</h3>
            <input type="text" name="CName" id="categoryName" placeholder="Category Name">
            <button onclick="saveCategory()">Add</button>
        </div>
    </div>

    <!-- Product Modal -->
    <div id="productModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeProductModal()">&times;</span>
            <h3>Add Product</h3>
            <input type="text" id="productName" placeholder="Product Name">
            <input type="text" id="productDescription" placeholder="Product Description">
            <input type="number" id="productPrice" placeholder="Product Price">
            <input type="number" id="productAmount" placeholder="Product amount">
            <input type="file" id="productImages" multiple>
            <button onclick="saveProduct()">Add Product</button>
        </div>
    </div>

    <!-- Edit Product Modal -->
    <div id="editModal" class="modal">
        <div class="modal-content">
            <span class="close" onclick="closeEditModal()">&times;</span>
            <h3>Edit Product</h3>
            <input type="hidden" id="editProductId">
            <input type="text" id="editProductName" placeholder="Product Name">
            <input type="text" id="editProductDescription" placeholder="Product Description">
            <input type="number" id="editProductPrice" placeholder="Product Price">
            <input type="number" id="editproductAmount" placeholder="Product amount">
            <input type="file" id="editProductImages" multiple>
            <button onclick="saveedit()">Save Changes</button>
        </div>
    </div>

    <script>


        let currentCategoryId = null;
        let currentProductId = null;
        let PrID = null;
        function openCategoryModal() { $("#categoryModal").show(); }
        function closeCategoryModal() { $("#categoryModal").hide(); }
        function openProductModal(categoryId) { currentCategoryId = categoryId; $("#productModal").show(); }
        function closeProductModal() { $("#productModal").hide(); }
        
        function saveCategory() {
    let categoryName = $("#categoryName").val();
    if (!categoryName) {
        alert("Category name required!");
        return;
    }

    $.post("sellerpage.php", { action: "add_Category", categoryName: categoryName }, function (response) {
        location.reload();
            let data = JSON.parse(response);
            if (data.error) {
                alert(data.error);
            } else {
                location.reload();
            }
       
    });
}

function viewOrders() {
    $.ajax({
        url: "sellerpage.php",
        type: "POST",
        data: { action: "get_orders" },
        success: function(response) {
            $("body").append(response);
            $("#ordersModal").show();
        },
        error: function(xhr) {
            alert("Failed to load orders: " + xhr.responseText);
        }
    });
}

function commentmod(productid) {
    $.ajax({
        url: "sellerpage.php",
        type: "POST",
        data: {
            action: "commentsRev",
            product_id: productid
        },
        success: function(response) {
            $("body").append(response);
            $("#Cmodal").show();
        },
        error: function(xhr) {
            alert("Failed to load comments: " + xhr.responseText);
        }
    });
}


function closeEditModal() {
    $("#editModal").hide();
}


function openEditproduct(productId) {
    currentProductId = productId;

    $.ajax({
        url: "sellerpage.php",
        type: "POST",
        data: {
            action: "get_product",
            product_id: productId
        },
       success: function (response) {
           

            let parts = response.split('|');
            if (parts.length < 5) {
                alert("Invalid response from server");
                return;
            }

            $("#editProductId").val(parts[0]);
            $("#editProductName").val(parts[1]);
            $("#editProductDescription").val(parts[2]);
            $("#editProductPrice").val(parts[3]);
            $("#editproductAmount").val(parts[4]);
            $("#editModal").show();
        },
        error: function () {
            alert("Failed to fetch product details");
        }
    });
}

    function saveedit() {
    let productId = $("#editProductId").val();
    let productName = $("#editProductName").val();
    let productDescription = $("#editProductDescription").val();
    let productPrice = $("#editProductPrice").val();
    let amount = $("#editproductAmount").val();
    let files = $("#editProductImages")[0].files;
    
    if (!productName || !productPrice) {
        alert("Product name and price are required!");
        return;
    }

    let formData = new FormData();
    formData.append("action", "edit_product");
    formData.append("product_id", productId);
    formData.append("name", productName);
    formData.append("description", productDescription);
    formData.append("Price", productPrice);
    formData.append("amount",amount)

    for (let i = 0; i < files.length; i++) {
        formData.append("images[]", files[i]);
    }

    $.ajax({
        url: "sellerpage.php",
        type: "POST",
        data: formData,
        processData: false,
        contentType: false,
        success: function (response) {
            
            location.reload();
        },
        error: function (xhr) {
            alert("Error updating product: " + xhr.responseText);
        }
    });
}


function performSearch() {
    const searchTerm = $("#searchInput").val().toLowerCase().trim();
    
    if (!searchTerm) {
        clearSearch();
        return;
    }
    
    // Hide all sections and products initially
    $(".section").hide();
    $(".product-item").hide();
    
    let foundResults = false;
    
    // Search categories
    $(".section h3").each(function() {
        const categoryName = $(this).text().toLowerCase();
        if (categoryName.includes(searchTerm)) {
            $(this).closest(".section").show();
            $(this).closest(".section").find(".product-item").show();
            foundResults = true;
        }
    });
    
    // Search products
    $(".product-item").each(function() {
        const productName = $(this).find("p:first").text().toLowerCase();
        const productDesc = $(this).find("p:nth-child(2)").text().toLowerCase();
        if (productName.includes(searchTerm) || productDesc.includes(searchTerm)) {
            $(this).show();
            $(this).closest(".section").show();
            foundResults = true;
        }
    });
    
    if (!foundResults) {
        // Show a "no results" message
        if ($("#noResultsMessage").length === 0) {
            $("<div id='noResultsMessage' style='text-align:center; padding:20px;'>No matching categories or products found.</div>").insertAfter(".search-container");
        }
    } else {
        $("#noResultsMessage").remove();
    }
}

    function closeModal(event) {
         if (event.target.classList.contains('detailmodal')) {
           $(event.target).hide();
        }
     }


function clearSearch() {
    $("#searchInput").val("");
    $(".section").show();
    $(".product-item").show();
    $("#noResultsMessage").remove();
}

let debounceTimer;

$("#searchInput").on("input", function () {
    clearTimeout(debounceTimer);
    debounceTimer = setTimeout(function () {
        performSearch();
    }, 300); 
});





    function saveProduct() {
    let productName = $("#productName").val();
    let productDescription = $("#productDescription").val();
    let productPrice = $("#productPrice").val();
    let pamount = $("#productAmount").val();
    let files = $("#productImages")[0].files;

    if (!productName || !productPrice) {
        alert("Product name and price are required!");
        return;
    }

    let formData = new FormData();
    formData.append("action", "add_product");
    formData.append("category_id", currentCategoryId);
    formData.append("name", productName);
    formData.append("description", productDescription);
    formData.append("price", productPrice);
    formData.append("amount", pamount);
    for (let i = 0; i < files.length; i++) {
        formData.append("images[]", files[i]);
    }
    $.ajax({
    url: "sellerpage.php",
    type: "POST",
    data: formData,
    processData: false,
    contentType: false,
    success: function (response) {
        console.log("Raw Response:", response);
        
        location.reload();
            let jsonResponse = JSON.parse(response);
            console.log("Parsed JSON:", jsonResponse);

            if (jsonResponse.error) { 
                alert("Error: " + jsonResponse.error);
            } else { 
                alert("Product added successfully!");
                window.location.reload();
            }
         
    },
    error: function (xhr, status, error) {
        console.error("AJAX Error:", status, error);
        console.error("Server Response:", xhr.responseText);
        alert("An error occurred: " + xhr.responseText);
    }
});
}

    function closeModal(event) {
    if (event.target.classList.contains('detailmodal') || event.target.classList.contains('close')) {
        $(".detailmodal").hide(); 
        document.location.reload();
    }
}

function openProductDetails(productId) {
    $.ajax({
        url: "sellerpage.php",
        type: "POST",
        data: {
            action: "get_product_details",
            product_id: productId
        },
        success: function (response) {
            $("body").append(response);
            $("#productDetailsModal").show();
        },
        error: function () {
            alert("Failed to fetch product details");
        }
    });
}

    function closeCategoryModal() {
         $("#categoryModal").hide();
    }

    function closeProductModal() {
        $("#productModal").hide();
    }

    function closeEditModal() {
        $("#editModal").hide();
    }

        
        
        
    </script>
</body>
</html>