<?php
session_start();
require 'C:\xampp\htdocs\seller\config.php';

if (isset($_POST['subLog'])) {
    $email = $_POST['email'];
    $pass = $_POST['pass'];
    
    // First query to get seller details
    $sql = "SELECT id, Password, Name, Type FROM seller WHERE Email = :email";
    $stmt = $pdo->prepare($sql);
    $stmt->bindParam(':email', $email, PDO::PARAM_STR);
    
    if ($stmt->execute()) {
        $seller = $stmt->fetch(PDO::FETCH_ASSOC);
        
        if ($seller) {
            // Verify password
            if (password_verify($pass, $seller['Password'])) {
                // Second query to get shop type
                $tid = $seller['Type'];
                $sql2 = "SELECT type FROM shoptypes WHERE ID = :tid";
                $stmt2 = $pdo->prepare($sql2);
                $stmt2->bindParam(':tid', $tid, PDO::PARAM_INT);
                
                if ($stmt2->execute()) {
                    $shoptype = $stmt2->fetch(PDO::FETCH_ASSOC);
                    
                    // Set session variables
                    $_SESSION['id'] = $seller['id'];
                    $_SESSION['selname'] = $seller['Name'];
                    $_SESSION['seltype'] = $shoptype['type'];
                    $_SESSION['email'] = $email;
                    
                    // Handle remember me cookie
                    if (!empty($_POST['remember'])) {
                        setcookie("email", $email, time() + (86400 * 7), "/");
                    } else {
                        setcookie("email", "", time() - 3600, "/");
                    }
                    
                    header("Location: /seller/sellerpages/sellerpage.php");
                    exit();
                } else {
                    echo "<script>alert('Failed to retrieve shop type.'); window.location.href = '/seller/login/logIn.php';</script>";
                }
            } else {
                echo "<script>alert('Wrong password.'); window.location.href = '/seller/login/logIn.php';</script>";
            }
        } else {
            echo "<script>alert('Wrong email.'); window.location.href = '/seller/login/logIn.php';</script>";
        }
    } else {
        echo "<script>alert('Database query failed.'); window.location.href = '/seller/login/logIn.php';</script>";
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seller Login</title>
    <link rel="stylesheet" href="LogIn.css">
    <link href='https://unpkg.com/boxicons@2.1.4/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
    <div class="wrapper">
    <form action="logIn.php" method="POST" >
       <h1>Login</h1>
        <div class = "input-box">
        <input type="email" name="email" placeholder="Email" value="<?php if(isset($_COOKIE['email'])) echo $_COOKIE['email']; ?>" required>

        <i class='bx bx-user'></i>
    </div>
        <div class = "input-box">
        <input type = "password" name="pass" placeholder = "Password" required>
        <i class='bx bx-lock-alt' ></i>
    </div>
    <div class = "remember-forget">
    <label> <input type = "checkbox"> Remember me</label>
    </br>
    <a href = " ..\resetforgotpass\PassForg.html"> Forgot Password? </a>
    </div>
    <button type = "submit" name = "subLog" class = "btn"> login</button>
    <div class = "register-link">
    <p>Don't have an account? <a href="../signup/submit.php">Sign Up</a></p>
    </form>
    </div>
</body>
</html>
