<?php
$host = 'localhost';
$db   = 'delivery_order_tracking_system';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';

$dsn = "mysql:host=$host;dbname=$db;charset=$charset";
$options = [
    PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
];

try {
    $pdo = new PDO($dsn, $user, $pass, $options);
} catch (\PDOException $e) {
    exit("Database connection failed: " . $e->getMessage());
}

define('ENCRYPTION_KEY', 'your-32-character-key------'); 
define('ENCRYPTION_IV', '1234567890abcdef');  

function encryptPassword($password) {
    return openssl_encrypt($password, 'AES-256-CBC', ENCRYPTION_KEY, 0, ENCRYPTION_IV);
}

function decryptPassword($encryptedPassword) {
    return openssl_decrypt($encryptedPassword, 'AES-256-CBC', ENCRYPTION_KEY, 0, ENCRYPTION_IV);
}

// Insert or Update
if ($_SERVER["REQUEST_METHOD"] === "POST") {
    if ($_POST['action'] === 'save') {
        $name = $_POST['name'];
        $email = $_POST['email'];
        $password = encryptPassword($_POST['password']);
        $phone = $_POST['phone'];

        if (!empty($_POST['agent_id'])) {
            $stmt = $pdo->prepare("UPDATE Delivery_Agent SET Name = ?, Email = ?, Password = ?, Phone = ? WHERE id = ?");
            $stmt->execute([$name, $email, $password, $phone, $_POST['agent_id']]);
        } else {
            $stmt = $pdo->prepare("INSERT INTO Delivery_Agent (Name, Email, Password, Phone) VALUES (?, ?, ?, ?)");
            $stmt->execute([$name, $email, $password, $phone]);
        }

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // Delete
    if ($_POST['action'] === 'delete' && !empty($_POST['agent_id'])) {
        $stmt = $pdo->prepare("DELETE FROM Delivery_Agent WHERE id = ?");
        $stmt->execute([$_POST['agent_id']]);

        header("Location: " . $_SERVER['PHP_SELF']);
        exit;
    }

    // View passwords
    if ($_POST['action'] === 'view_passwords') {
        $search_name = $_POST['search_name'];
        $stmt = $pdo->prepare("SELECT Name, Email, Password FROM Delivery_Agent WHERE Name = ?");
        $stmt->execute([$search_name]);
        $passwordResults = $stmt->fetchAll();
    }
}

// Fetch agents
$agents = $pdo->query("SELECT Name, Email, Phone FROM Delivery_Agent")->fetchAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Admin - Manage Delivery Agents</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #eee;
            padding: 20px;
        }
        form, table {
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 30px;
            box-shadow: 0 0 10px #ccc;
        }
        input, button {
            margin: 10px 0;
            padding: 8px;
            width: 100%;
            box-sizing: border-box;
        }
        table {
            width: 100%;
            border-collapse: collapse;
        }
        .cont{
            margin-left:10px;
        }
        th, td {
            padding: 12px;
            border-bottom: 1px solid #ddd;
        }
        .edit-btn {
            cursor: pointer;
            color: blue;
            text-decoration: underline;
        }
        .hidden {
            display: none;
        }
    </style>
</head>
<body>

<h2>Create / Edit / Delete Delivery Agent</h2>
<form id="agentForm" method="POST">
    <input type="hidden" name="agent_id" id="agent_id">
    <input type="hidden" name="action" value="save" id="form_action">

    <label>Name:</label>
    <input type="text" name="name" id="name" required>

    <label>Email:</label>
    <input type="email" name="email" id="email" required>

    <label>Password:</label>
    <input type="text" name="password" id="password" required>

    <label>Phone:</label>
    <input type="text" name="phone" id="phone" required>

    <button type="submit">Submit</button>
    <button type="button" class="hidden" id="deleteBtn" onclick="deleteAgent()">Delete Agent</button>
</form>

<h2>Existing Delivery Agents</h2>
<table>
    <thead>
    <tr>
        <th>Name</th>
        <th>Email</th>
        <th>Phone</th>
        <th>Edit</th>
    </tr>
    </thead>
    <tbody>
    
    <?php foreach ($agents as $agent): ?>
        <tr>
        <div class = "cont">
            <td class = "cont"><?= htmlspecialchars($agent['Name']) ?></td>
            <td><?= htmlspecialchars($agent['Email']) ?></td>
            <td><?= htmlspecialchars($agent['Phone']) ?></td>
            <td><span class="edit-btn" onclick='editAgent(<?= json_encode($agent) ?>)'>Edit</span></td>
        </div>
        
        </tr>
    <?php endforeach; ?>
    </tbody>
</table>

<h2>View Delivery Agent Passwords by Name</h2>
<form method="POST">
    <input type="hidden" name="action" value="view_passwords">
    <label>Enter Name:</label>
    <input type="text" name="search_name" required>
    <button type="submit">View Passwords</button>
</form>

<?php if (!empty($passwordResults)): ?>
    <h3>Passwords Found:</h3>
    <ul>
        <?php foreach ($passwordResults as $row): ?>
            <li>
                <strong>Name:</strong> <?= htmlspecialchars($row['Name']) ?> |
                <strong>Email:</strong> <?= htmlspecialchars($row['Email']) ?> |
                <strong>Password:</strong> <?= htmlspecialchars(decryptPassword($row['Password'])) ?>
            </li>
        <?php endforeach; ?>
    </ul>
<?php endif; ?>

<script>
    function editAgent(agent) {
        document.getElementById('agent_id').value = agent.id;
        document.getElementById('name').value = agent.Name;
        document.getElementById('email').value = agent.Email;
        document.getElementById('phone').value = agent.Phone;
        document.getElementById('password').value = ''; // Do not prefill password
        document.getElementById('deleteBtn').classList.remove('hidden');
    }

    function deleteAgent() {
        if (confirm("Are you sure you want to delete this agent?")) {
            const form = document.getElementById('agentForm');
            document.getElementById('form_action').value = 'delete';
            form.submit();
        }
    }
</script>

</body>
</html>
